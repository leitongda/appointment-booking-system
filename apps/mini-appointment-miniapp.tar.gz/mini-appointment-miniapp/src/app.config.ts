export default defineAppConfig({
  pages: [
    'pages/home/index',
    'pages/scan/index'
  ],
  subPackages: [
    {
      root: 'pages/appointment',
      pages: [
        'department/index',
        'doctor/index',
        'schedule/index',
        'confirm/index'
      ]
    },
    {
      root: 'pages/profile',
      pages: [
        'index',
        'patients/index',
        'patients/edit',
        'appointments/index',
        'appointments/detail',
        'favorites/index',
        'feedback/index',
        'settings/index'
      ]
    }
  ],
  preloadRule: {
    'pages/home/index': {
      network: 'all',
      packages: ['pages/appointment']
    }
  },
  window: {
    backgroundTextStyle: 'light',
    navigationBarBackgroundColor: '#fff',
    navigationBarTitleText: '医疗挂号',
    navigationBarTextStyle: 'black',
    backgroundColor: '#f5f5f5'
  },
  tabBar: {
    color: '#999999',
    selectedColor: '#1890ff',
    backgroundColor: '#ffffff',
    borderStyle: 'black',
    list: [
      {
        pagePath: 'pages/home/index',
        text: '首页',
        iconPath: 'assets/icons/home.png',
        selectedIconPath: 'assets/icons/home-active.png'
      },
      {
        pagePath: 'pages/scan/index',
        text: '扫码签到',
        iconPath: 'assets/icons/scan.png',
        selectedIconPath: 'assets/icons/scan-active.png'
      },
      {
        pagePath: 'pages/profile/index',
        text: '我的',
        iconPath: 'assets/icons/profile.png',
        selectedIconPath: 'assets/icons/profile-active.png'
      }
    ]
  },
  permission: {
    'scope.userLocation': {
      desc: '您的位置信息将用于获取附近的医院'
    }
  }
});
